
import pandas as pd
from sklearn.tree import DecisionTreeClassifier
import joblib

def train_model(csv_path="Karnataka_Disaster_Realistic_Dataset.csv", model_path="model.pkl"):
    df = pd.read_csv(csv_path)

    # First column is district name
    X = df.iloc[:, 1:]  # numeric features
    y = df.iloc[:, 1:].idxmax(axis=1)  # label = highest occurring disaster

    model = DecisionTreeClassifier()
    model.fit(X, y)

    joblib.dump(model, model_path)
    print(f"Model trained and saved to {model_path}")

if __name__ == "__main__":
    train_model()
