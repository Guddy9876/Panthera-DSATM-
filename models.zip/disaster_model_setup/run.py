import requests
import pandas as pd
import joblib
import os

# ==============================
# EDIT THESE TWO PATHS
# ==============================
CSV_PATH   = r"C:\Users\patil\OneDrive\Pictures\Desktop\DSATM Hack-Spark\disaster_model_setup\Karnataka_Disaster_Realistic_Dataset.csv"
MODEL_PATH = r"C:\Users\patil\OneDrive\Pictures\Desktop\DSATM Hack-Spark\disaster_model_setup\model.pkl"


# Normalize helper
def normalize(text):
    return str(text).strip().lower()


# District alias correction mapping
district_alias_map = {
    "bangalore urban": "bengaluru urban",
    "bangalore city": "bengaluru urban",
    "bangalore north": "bengaluru urban",
    "bengaluru north": "bengaluru urban",
    "bangalore south": "bengaluru urban",

    "bangalore rural": "bengaluru rural",
    "bengaluru rural": "bengaluru rural",

    "mysore": "mysuru",
    "belgaum": "belagavi",
    "tumkur": "tumakuru",
    "bellary": "ballari",
    "chikmagalur": "chikkamagaluru",
    "shimoga": "shivamogga",
}


def correct_district_name(name):
    n = normalize(name)
    return district_alias_map.get(n, n)


#===========================================
# Get approx location from IP
#===========================================
def get_location():
    try:
        res = requests.get("https://ipinfo.io/json")
        data = res.json()
        lat, lng = map(float, data["loc"].split(","))
        return lat, lng
    except Exception as e:
        print("Location fetch error:", e)
        return None, None


#===========================================
# Reverse geocode → district name
#===========================================
def reverse_geocode(lat, lng):
    try:
        url = f"https://nominatim.openstreetmap.org/reverse?lat={lat}&lon={lng}&format=json"
        data = requests.get(url, headers={"User-Agent": "AlertMate"}).json()

        if "address" in data:
            address = data["address"]

            district = (
                address.get("county") or
                address.get("state_district") or
                address.get("city") or
                address.get("town")
            )

            return district
    except:
        pass

    return None


#===========================================
# Predict using the district
#===========================================
def predict_for_district(district_name, csv_path=CSV_PATH, model_path=MODEL_PATH):
    df = pd.read_csv(csv_path)

    # Normalize dataset districts
    df["normalized"] = df.iloc[:,0].apply(normalize)

    district_norm = normalize(district_name)

    if district_norm not in df["normalized"].values:
        return {
            "error": f"District '{district_name}' not found in dataset."
        }

    # Exclude first column (district name) and last (normalized)
    row = df[df["normalized"] == district_norm].iloc[:, 1:-1]

    model = joblib.load(model_path)

    prediction = model.predict(row)[0]

    top3 = row.squeeze().nlargest(3).index.tolist()

    return {
        "district": district_name,
        "top_disaster": prediction,
        "top3_disasters": top3,
    }


#===========================================
# MAIN
#===========================================
if __name__ == "__main__":
    print("Fetching your current location...")

    lat, lng = get_location()

    if lat is None:
        print("Could not fetch location.")
        exit()

    print(f"Your location: {lat}, {lng}")

    print("Finding your district...")
    district = reverse_geocode(lat, lng)

    if district is None:
        print("Could not determine your district.")
        exit()

    print(f"Detected District (raw): {district}")

    # Apply name correction
    corrected = correct_district_name(district)
    print(f"Corrected District Name: {corrected}")

    print("Predicting disasters for your district...")
    result = predict_for_district(corrected)

    print("\n====== AlertMate Risk Report ======")
    if "error" in result:
        print(result["error"])
    else:
        print(f"District: {result['district']}")
        print(f"Most Likely Disaster: {result['top_disaster']}")
        print(f"Top 3 Disasters: {result['top3_disasters']}")
