from flask import Flask, jsonify
from flask_cors import CORS
import smtplib
from email.mime.text import MIMEText
import random

app = Flask(__name__)
CORS(app)

# -----------------------------
# CONFIGURE YOUR EMAIL SENDER
# -----------------------------
SENDER_EMAIL = "patil.hc1@gmail.com"
APP_PASSWORD = "iiig xkxy qmmo zbcv"     # Gmail App Password
RECIPIENTS = [
    "guddeshhpatil@gmail.com",
    "karthikkarthik95833@gmail.com",
    "rakshith0125@gmail.com"
]

# -----------------------------
# FLOOD SIMULATION VALUE
# -----------------------------
river_level = 1
alert_sent = False   # prevents repeated emails


@app.route("/live_flood")
def live_flood():
    global river_level, alert_sent

    river_level += 1
    if river_level > 150:
        river_level = 150

    # send email ONCE
    if river_level >= 100 and not alert_sent:
        try:
            send_flood_email(river_level)
            alert_sent = True
            print("📧 Flood email sent!")
        except Exception as e:
            print("❌ EMAIL ERROR:", e)

    return jsonify({
        "water_level": river_level,
        "alert": river_level >= 100
    })


# -----------------------------
# LIVE RAINFALL API
# -----------------------------
@app.route("/live_rainfall")
def live_rainfall():

    return jsonify({
        "rainfall_intensity": round(random.uniform(0, 30), 2),   # mm/hr
        "rainfall_today": round(random.uniform(0, 80), 2),       # mm
        "cloud_cover": random.randint(20, 100),                  # %
        "visibility": round(random.uniform(1, 10), 2)            # km
    })


# -----------------------------
# LIVE AIR QUALITY API
# -----------------------------
@app.route("/live_air")
def live_air():

    return jsonify({
        "AQI": random.randint(50, 300),
        "PM25": round(random.uniform(10, 150), 2),
        "PM10": round(random.uniform(20, 200), 2),
        "OZONE": round(random.uniform(5, 80), 2)
    })


# -----------------------------
# EMAIL FUNCTION
# -----------------------------
def send_flood_email(value):
    body = (
        f"🚨 ALERTMATE FLOOD WARNING 🚨\n\n"
        f"River water level is above safe limits.\n"
        f"Current level: {value}\n\n"
        f"Immediate action advised.\n\n"
        f"- AlertMate Automated System"
    )

    msg = MIMEText(body)
    msg["Subject"] = "🚨 AlertMate — Flood Warning"
    msg["From"] = SENDER_EMAIL
    msg["To"] = ", ".join(RECIPIENTS)

    server = smtplib.SMTP("smtp.gmail.com", 587)
    server.starttls()
    server.login(SENDER_EMAIL, APP_PASSWORD)
    server.sendmail(SENDER_EMAIL, RECIPIENTS, msg.as_string())
    server.quit()


@app.route("/")
def home():
    return "AlertMate Flood Server Running", 200


@app.route("/reset")
def reset_values():
    global river_level, alert_sent
    river_level = 1
    alert_sent = False
    return jsonify({"status": "reset"})


# -----------------------------
# RUN SERVER (MUST BE LAST)
# -----------------------------
if __name__ == "__main__":
    print("\n🚀 Server running at: http://127.0.0.1:5000/\n")
    app.run(port=5000, debug=True)
