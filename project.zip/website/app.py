from flask import Flask, jsonify
from flask_cors import CORS
import smtplib
from email.mime.text import MIMEText
import random

app = Flask(__name__)
CORS(app)

# -----------------------------
# EMAIL CONFIG
# -----------------------------
SENDER_EMAIL = "patil.hc1@gmail.com"
APP_PASSWORD = "iiig xkxy qmmo zbcv"

RECIPIENTS = [
    "guddeshhpatil@gmail.com",
    "karthikkarthik95833@gmail.com",
    "rakshith0125@gmail.com"
]

# -----------------------------
# FLOOD SIMULATION VALUE
# -----------------------------
river_level = 1
early_sent = False
final_sent = False


@app.route("/live_flood")
def live_flood():
    global river_level, early_sent, final_sent

    # Increase level
    river_level += 1
    if river_level > 150:
        river_level = 150

    # ------------------------
    # EARLY WARNING (>80)
    # ------------------------
    if river_level >= 80 and not early_sent:
        try:
            send_email(
                RECIPIENTS,
                "⚠️ Early Flood Warning",
                f"Water level is rising.\nCurrent level: {river_level}\nPlease stay alert."
            )
            early_sent = True
            print("📧 Early Warning Sent!")
        except Exception as e:
            print("❌ Early Warning Error:", e)

    # ------------------------
    # FINAL WARNING (>100)
    # ------------------------
    if river_level >= 100 and not final_sent:
        try:
            send_email(
                RECIPIENTS,
                "🚨 FINAL FLOOD WARNING — DANGER",
                f"Critical water level detected!\nCurrent level: {river_level}\nImmediate action required!"
            )
            final_sent = True
            print("📧 FINAL WARNING SENT!")
        except Exception as e:
            print("❌ Final Warning Error:", e)

    return jsonify({
        "water_level": river_level,
        "alert": river_level >= 100
    })


# -----------------------------
# RAINFALL API
# -----------------------------
@app.route("/live_rainfall")
def live_rainfall():
    return jsonify({
        "rainfall_intensity": round(random.uniform(0, 30), 2),
        "rainfall_today": round(random.uniform(0, 80), 2),
        "cloud_cover": random.randint(20, 100),
        "visibility": round(random.uniform(1, 10), 2)
    })


# -----------------------------
# AIR QUALITY API
# -----------------------------
@app.route("/live_air")
def live_air():
    return jsonify({
        "AQI": random.randint(50, 300),
        "PM25": round(random.uniform(10, 150), 2),
        "PM10": round(random.uniform(20, 200), 2),
        "OZONE": round(random.uniform(5, 80), 2)
    })


# -----------------------------
# EMAIL FUNCTION
# -----------------------------
def send_email(to_list, subject, body):
    msg = MIMEText(body)
    msg["Subject"] = subject
    msg["From"] = SENDER_EMAIL
    msg["To"] = ", ".join(to_list)

    server = smtplib.SMTP("smtp.gmail.com", 587)
    server.starttls()
    server.login(SENDER_EMAIL, APP_PASSWORD)
    server.sendmail(SENDER_EMAIL, to_list, msg.as_string())
    server.quit()


@app.route("/")
def home():
    return "AlertMate Flood Server Running", 200


@app.route("/reset")
def reset_values():
    global river_level, early_sent, final_sent
    river_level = 1
    early_sent = False
    final_sent = False
    return jsonify({"status": "reset"})


if __name__ == "__main__":
    print("\n🚀 Server running at http://127.0.0.1:5000/\n")
    app.run(port=5000, debug=True)
